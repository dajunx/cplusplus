#ifndef MESSAGE_DISPATCH
#define MESSAGE_DISPATCH
#include "common_def.h"

typedef boost::function<void()> fun_;
extern std::vector<fun_ > fun_vec;

#define HANDLE_PROTO(index) \
  fun_vec[##index] = boost::bind(&fun##index);

#define FUN_LIST(index) \
  static void fun##index() \
{ \
  std::cout<<"fun "<<index<<std::endl; \
}

class message_mgr
{
public:
  message_mgr() {}
  ~message_mgr() {}

  FUN_LIST(1);
  FUN_LIST(2);
  FUN_LIST(3);

  void dispatch_msg(int index)
  {
    fun_vec[index]();
  }

  void registe_msg_mgr()
  {
    HANDLE_PROTO(1);
    HANDLE_PROTO(2);
    HANDLE_PROTO(3);
  }
};

#endif