#include "network_mgr.h"
#include "message_dispatch.h"
std::vector<fun_ > fun_vec;

int main()
{
  //init
  message_mgr msg_mgr;
  fun_vec.resize(4);
  msg_mgr.registe_msg_mgr();

  //��Ϣ����
//   for (int i=1; i< 4;++i)
//   {
//     dispatch_msg(i);
//   }

  boost::asio::io_service io_service;
  boost::asio::io_service::work work(io_service);
  boost::thread th(boost::bind(&boost::asio::io_service::run, boost::ref(io_service)));
  th.detach();

  boost::uint32_t port = 9999;
  server s(io_service, port);
  s.accept_client_conn_loop();

  return 0;
}